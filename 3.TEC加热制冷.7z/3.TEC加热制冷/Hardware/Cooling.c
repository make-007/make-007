/*---------------------------------------
&&&--����===���ճ�
&&&--˵��===TEC����Ƭ�����߼�
&&&--ʱ��===2024.9.18
&&&--��Ŀ===
-----------------------------------------*/

#include "stm32f10x.h"                  // Device header
#include "Cooling.h"
#include "TIM2.h"

/*
*********************************************************************************************************
*	�� �� ��: Cooling_Init
*	����˵��: ��������Ƭ
*	��    �Σ�
*	�� �� ֵ: 
*********************************************************************************************************
*/
void Cooling_Init(void)
{
	GPIO_InitTypeDef	GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);		

	GPIO_InitStructure.GPIO_Mode	=	GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin 	=	GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed 	=	GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
 
	PWM_Init();
}

void Cooling_SetSpeed(int8_t Speed)
{
	if(Speed>=0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_6);
		GPIO_ResetBits(GPIOA,GPIO_Pin_7);
		PWM_SetCompare4(Speed);
	}
}





