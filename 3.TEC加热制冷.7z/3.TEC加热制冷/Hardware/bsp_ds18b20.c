/*
*********************************************************************************************************
*
*	模块名称 : DS18B20温度检测模块
*	文件名称 : bsp_ds18b20.c
*	说    明 : 
*	修改记录 :
*@ time:	2024/09/02 17:11
*		版本号   作者     说明
*		V1.0    李二狗      
*
*	Copyright (C),2024--,天津市大学软件学院
*
*********************************************************************************************************
*/
 
///////////////////////////////////////
/* 头文件包含区 */
 #include "bsp_ds18b20.h"               // 单片机头文件
 #include "delay.h"                     //延时
//////////////////////////////////////
/* 变量定义区 */
 
///////////////////////////////////////
/* 外部变量申明区 */
 
///////////////////////////////////////
/* 函数申明区 */
 
///////////////////////////////////////
/* 函数实体区 */

/**
*@ name:	 DS18B20_Rst
*@ usage:	 DS18B20复位
*@ input:	 无
*@ output:	 无
*@ author:	李二狗 
*@ time:	2024/09/10 14:30
*/

void DS18B20_Rst(void)	   
{                 
	DS18B20_Mode(OUT); 	//SET OUTPUT
    DS18B20_Low; 				//拉低DQ
    Delay_us(750);    	//拉低750us
    DS18B20_High; 			//DQ=1 
	Delay_us(15);     	//15US
}
/**
*@ name:	 DS18B20_Check
*@ usage:	 等待DS18B20的回应
*@ input:	 无
*@ output:	 1：未检测到DS18B20的存在           0：存在
*@ author:	李二狗 
*@ time:	2024/09/10 14:31
*/
u8 DS18B20_Check(void) 	   
{   
	u8 retry=0;
	DS18B20_Mode(IN);	//SET  INPUT	 
    while (GPIO_ReadInputDataBit(DS18B20_GPIO_PORT,DS18B20_GPIO_PIN)&&retry<200)
	{
		retry++;
		Delay_us(1);
	};	 
	if(retry>=200)return 1;
	else retry=0;
    while (!GPIO_ReadInputDataBit(DS18B20_GPIO_PORT,DS18B20_GPIO_PIN)&&retry<240)
	{
		retry++;
		Delay_us(1);
	};
	if(retry>=240)return 1;	    
	return 0;
}
/**
*@ name:	 DS18B20_Read_Bit
*@ usage:	 从DS18B20读取一个位
*@ input:	 无
*@ output:	 1/0
*@ author:	李二狗 
*@ time:	2024/09/10 14:31
*/
u8 DS18B20_Read_Bit(void) 	 
{
    u8 data;
	DS18B20_Mode(OUT);	//SET OUTPUT
    DS18B20_Low; 
	Delay_us(2);
    DS18B20_High; 
	DS18B20_Mode(IN);	//SET INPUT
	Delay_us(12);
	if(GPIO_ReadInputDataBit(DS18B20_GPIO_PORT,DS18B20_GPIO_PIN))data=1;
    else data=0;	 
    Delay_us(50);           
    return data;
}
/**
*@ name:	 DS18B20_Read_Byte
*@ usage:	 从DS18B20读取一个字节
*@ input:	 无
*@ output:	 读到的数据
*@ author:	李二狗 
*@ time:	2024/09/10 14:32
*/
u8 DS18B20_Read_Byte(void)     
{        
    u8 i,j,dat;
    dat=0;
	for (i=1;i<=8;i++) 
	{
        j=DS18B20_Read_Bit();
        dat=(j<<7)|(dat>>1);
    }						    
    return dat;
}
/**
*@ name:	 DS18B20_Write_Byte
*@ usage:	 写一个字节到DS18B20
*@ input:	 要写入的字节
*@ output:	 无
*@ author:	李二狗 
*@ time:	2024/09/10 14:32
*/
void DS18B20_Write_Byte(u8 dat)     
 {             
    u8 j;
    u8 testb;
	DS18B20_Mode(OUT);	//SET OUTPUT;
    for (j=1;j<=8;j++) 
	{
        testb=dat&0x01;
        dat=dat>>1;
        if (testb) 
        {
            DS18B20_Low;	// Write 1
            Delay_us(2);                            
            DS18B20_High;
            Delay_us(60);             
        }
        else 
        {
            DS18B20_Low;	// Write 0
            Delay_us(60);             
            DS18B20_High;
            Delay_us(2);                          
        }
    }
}
/**
*@ name:	 DS18B20_Start
*@ usage:	 开始温度转换
*@ input:	 无
*@ output:	 无
*@ author:	李二狗 
*@ time:	2024/09/10 14:32
*/
void DS18B20_Start(void) 
{   						               
    DS18B20_Rst();	   
		DS18B20_Check();	 
    DS18B20_Write_Byte(0xcc);	// skip rom
    DS18B20_Write_Byte(0x44);	// convert
} 
 
/**
*@ name:	 DS18B20_Init
*@ usage:	 初始化DS18B20的IO口 DQ 同时检测DS的存在
*@ input:	无
*@ output:	  1：不存在  0:存在
*@ author:	李二狗 
*@ time:	2024/09/10 14:33
*/	 
u8 DS18B20_Init(void)
{
 	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 	RCC_APB2PeriphClockCmd(DS18B20_GPIO_CLK, ENABLE);	 //使能PORTA口时钟 
	
 	GPIO_InitStructure.GPIO_Pin = DS18B20_GPIO_PIN;				//PORTA.12 推挽输出
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		  
 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(DS18B20_GPIO_PORT, &GPIO_InitStructure);
 
 	GPIO_SetBits(DS18B20_GPIO_PORT,DS18B20_GPIO_PIN);    //输出1
 
	DS18B20_Rst();
 
	return DS18B20_Check();
} 
/**
*@ name:	 DS18B20_Get_Temp
*@ usage:	 从ds18b20得到温度值
*@ input:	 无
*@ output:	 温度值 （-550~1250）
*@ author:	李二狗 
*@ time:	2024/09/10 14:33
*/
float DS18B20_Get_Temp(void)
{
    u8 temp;
    u8 TL,TH;
	short                                                               tem;
    DS18B20_Start ();  			// ds1820 start convert
    DS18B20_Rst();
    DS18B20_Check();	 
    DS18B20_Write_Byte(0xcc);	// skip rom
    DS18B20_Write_Byte(0xbe);	// convert	    
    TL=DS18B20_Read_Byte(); 	// LSB   
    TH=DS18B20_Read_Byte(); 	// MSB  
	    	  
    if(TH>7)
    {
        TH=~TH;
        TL=~TL; 
        temp=0;					//温度为负  
    }else temp=1;				//温度为正	  	  
    tem=TH; 					//获得高八位
    tem<<=8;    
    tem+=TL;					//获得底八位
    tem=(float)tem*0.625;		//转换     
	if(temp)return tem; 		//返回温度值
	else return -tem;    
}
 /**
 *@ name:	 DS18B20_Mode
 *@ usage:	 配置 DS18B20 温度传感器的 GPIO 引脚为输入或输出模式。
 *@ input:	 
 *        u8 mode: 用于配置 GPIO 引脚的模式。
 *                  - 1: 将引脚配置为推挽输出模式。
 *                  - 0: 将引脚配置为浮空输入模式。
 *@ output:	 无
 *@ author:	李二狗 
 *@ time:	2024/09/10 14:34
 */
 
void DS18B20_Mode(u8 mode)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(DS18B20_GPIO_CLK, ENABLE);	 //使能PORTA口时钟
	
	if(mode)
	{
		GPIO_InitStructure.GPIO_Pin = DS18B20_GPIO_PIN;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	}
	else
	{
		GPIO_InitStructure.GPIO_Pin =  DS18B20_GPIO_PIN;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	}
	GPIO_Init(DS18B20_GPIO_PORT, &GPIO_InitStructure);
}
///////////////////////////////////////
 
/***************************** 天津市大学软件学院 (END OF FILE) *********************************/
