#include "stm32f10x.h"                  // Device header





/*
*********************************************************************************************************
*	�� �� ��: LED_Init
*	����˵��: LED��ʼ������
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; //�ṹ�嶨��
	//ʹ��RCC����ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	//���ö˿�ģʽ
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);

	GPIO_SetBits(GPIOA,GPIO_Pin_1 | GPIO_Pin_2);
}

//����LED1
void LED1_ON(void)
{
	GPIO_ResetBits(GPIOA ,GPIO_Pin_1);
}
//Ϩ��LED1
void LED1_OFF(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_1);
}

//----------------------------------------�˿ڵ�ƽ��ת
void LED1_Turn(void)
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_1) == 0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_1);
	}
	else 
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	}
}

//����LED2
void LED2_ON(void)
{
	GPIO_ResetBits(GPIOA ,GPIO_Pin_2);
}
//Ϩ��LED2
void LED2_OFF(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_2);
}
//----------------------------------------�˿ڵ�ƽ��ת
void LED2_Turn(void)
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_2) == 0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_2);
	}
	else 
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_2);
	}
}

