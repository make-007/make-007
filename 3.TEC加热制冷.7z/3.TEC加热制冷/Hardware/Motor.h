#ifndef _MOTOR_H
#define _MOTOR_H

void Motor_Init(void);
void Motor_SetSpeed(int8_t speed);

#endif
