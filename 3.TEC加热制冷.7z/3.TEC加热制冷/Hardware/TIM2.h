#ifndef _TIM2_H
#define _TIM2_H


void PWM_Init(void);
void PWM_SetCompare3(uint16_t speed);
void PWM_SetCompare4(uint16_t speed);


#endif
