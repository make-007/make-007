#ifndef _COOLING_H
#define _COOLING_H

void Cooling_Init(void);
void Cooling_SetSpeed(int8_t Speed);

#endif
