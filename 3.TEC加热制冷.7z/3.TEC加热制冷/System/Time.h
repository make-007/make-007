#ifndef _TIME_H
#define _TIME_H


extern volatile uint8_t flag500ms; 	// 500ms ��־
extern volatile uint8_t flag100ms;  // 100ms ��־

void Time3_Init(uint16_t psc,uint16_t period500ms,uint16_t period100ms);
void TIM3_IRQHandler(void);
void Start_Timer(void);

#endif





